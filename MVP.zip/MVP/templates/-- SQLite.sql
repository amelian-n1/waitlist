-- SQLite
DELETE * FROM waitlist
